import React from 'react';
import { Link } from 'react-router-dom';
import { Award, BookOpen, GraduationCap, Microscope, Building, ArrowRight } from 'lucide-react';

const About = () => {
  return (
    <>
      {/* Hero Section */}
      <section className="pt-32 pb-16 md:pt-40 md:pb-20 bg-primary text-white">
        <div className="container">
          <div className="text-center max-w-3xl mx-auto">
            <h1 className="text-4xl md:text-5xl font-bold mb-6 text-white">About Dr. Mahesh Babu</h1>
            <p className="text-lg text-white/90">
              A dedicated general surgeon with over 20 years of experience providing compassionate and expert surgical care in Hyderabad.
            </p>
          </div>
        </div>
      </section>

      {/* Bio Section */}
      <section className="section bg-white">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1">
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Meet Dr. Mahesh Babu</h2>
              <p className="mb-4 text-gray-700">
                Dr. Mahesh Babu is a highly respected general surgeon in Hyderabad with over two decades of clinical experience. 
                After completing his MBBS from Osmania Medical College and MS in General Surgery from Nizam's Institute of Medical Sciences, 
                he pursued specialized training in advanced laparoscopic techniques.
              </p>
              <p className="mb-4 text-gray-700">
                Throughout his career, Dr. Babu has been committed to providing patient-centered care, combining surgical expertise 
                with compassion and clear communication. He believes in treating each patient as an individual, taking time to understand 
                their concerns and develop personalized treatment plans.
              </p>
              <p className="mb-6 text-gray-700">
                Dr. Babu is affiliated with leading hospitals in Hyderabad and stays current with the latest surgical techniques 
                through ongoing professional development and active participation in medical conferences and workshops.
              </p>
              <Link to="/contact" className="btn btn-primary inline-flex items-center gap-2">
                Book a Consultation <ArrowRight size={18} />
              </Link>
            </div>
            <div className="order-1 lg:order-2 flex justify-center">
              <div className="w-full max-w-md aspect-square bg-gray-100 rounded-lg overflow-hidden shadow-xl">
                <img 
                  src="https://images.pexels.com/photos/5214958/pexels-photo-5214958.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                  alt="Dr. Mahesh Babu" 
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Education & Experience */}
      <section className="section bg-gray-50">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Education & Experience</h2>
            <p className="max-w-3xl mx-auto text-gray-600">
              Dr. Mahesh Babu's extensive training and professional experience has equipped him with the expertise to provide exceptional surgical care.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Education Column */}
            <div>
              <h3 className="text-2xl font-bold mb-6 flex items-center gap-3">
                <GraduationCap className="text-primary" size={28} />
                <span>Education</span>
              </h3>

              <div className="space-y-6">
                <div className="card p-6 border-l-4 border-primary">
                  <div className="flex items-center gap-3 mb-2">
                    <BookOpen className="text-primary" size={20} />
                    <h4 className="text-lg font-semibold">MBBS</h4>
                  </div>
                  <p className="text-gray-600 mb-1">Osmania Medical College, Hyderabad</p>
                  <p className="text-sm text-gray-500">1996 - 2002</p>
                </div>

                <div className="card p-6 border-l-4 border-primary">
                  <div className="flex items-center gap-3 mb-2">
                    <BookOpen className="text-primary" size={20} />
                    <h4 className="text-lg font-semibold">MS - General Surgery</h4>
                  </div>
                  <p className="text-gray-600 mb-1">Nizam's Institute of Medical Sciences, Hyderabad</p>
                  <p className="text-sm text-gray-500">2002 - 2005</p>
                </div>

                <div className="card p-6 border-l-4 border-primary">
                  <div className="flex items-center gap-3 mb-2">
                    <BookOpen className="text-primary" size={20} />
                    <h4 className="text-lg font-semibold">Fellowship in Advanced Laparoscopic Surgery</h4>
                  </div>
                  <p className="text-gray-600 mb-1">Asian Institute of Gastroenterology, Hyderabad</p>
                  <p className="text-sm text-gray-500">2005 - 2006</p>
                </div>
              </div>
            </div>

            {/* Experience Column */}
            <div>
              <h3 className="text-2xl font-bold mb-6 flex items-center gap-3">
                <Building className="text-primary" size={28} />
                <span>Professional Experience</span>
              </h3>

              <div className="space-y-6">
                <div className="card p-6 border-l-4 border-secondary">
                  <div className="flex items-center gap-3 mb-2">
                    <Microscope className="text-secondary" size={20} />
                    <h4 className="text-lg font-semibold">Senior Consultant - General Surgery</h4>
                  </div>
                  <p className="text-gray-600 mb-1">Apollo Hospitals, Hyderabad</p>
                  <p className="text-sm text-gray-500">2015 - Present</p>
                </div>

                <div className="card p-6 border-l-4 border-secondary">
                  <div className="flex items-center gap-3 mb-2">
                    <Microscope className="text-secondary" size={20} />
                    <h4 className="text-lg font-semibold">Consultant Surgeon</h4>
                  </div>
                  <p className="text-gray-600 mb-1">KIMS Hospitals, Hyderabad</p>
                  <p className="text-sm text-gray-500">2010 - 2015</p>
                </div>

                <div className="card p-6 border-l-4 border-secondary">
                  <div className="flex items-center gap-3 mb-2">
                    <Microscope className="text-secondary" size={20} />
                    <h4 className="text-lg font-semibold">Associate Surgeon</h4>
                  </div>
                  <p className="text-gray-600 mb-1">Yashoda Hospitals, Hyderabad</p>
                  <p className="text-sm text-gray-500">2006 - 2010</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Achievements Section */}
      <section className="section bg-white">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Achievements & Credentials</h2>
            <p className="max-w-3xl mx-auto text-gray-600">
              Dr. Mahesh Babu's professional recognitions and memberships highlight his standing in the medical community.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Card 1 */}
            <div className="card p-8 hover:shadow-lg transition-all">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-6">
                <Award size={28} className="text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Professional Memberships</h3>
              <ul className="list-disc list-inside space-y-2 text-gray-700">
                <li>Association of Surgeons of India</li>
                <li>Indian Association of Gastrointestinal Endo-Surgeons</li>
                <li>Telangana Surgical Society</li>
                <li>International College of Surgeons</li>
              </ul>
            </div>

            {/* Card 2 */}
            <div className="card p-8 hover:shadow-lg transition-all">
              <div className="w-16 h-16 bg-secondary/10 rounded-full flex items-center justify-center mb-6">
                <Award size={28} className="text-secondary" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Awards & Recognition</h3>
              <ul className="list-disc list-inside space-y-2 text-gray-700">
                <li>Best Surgeon Award, Hyderabad Medical Association, 2018</li>
                <li>Excellence in Surgical Care, Apollo Hospitals, 2020</li>
                <li>Recognition for Surgical Innovations, 2016</li>
                <li>Distinguished Service Award, 2022</li>
              </ul>
            </div>

            {/* Card 3 */}
            <div className="card p-8 hover:shadow-lg transition-all">
              <div className="w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center mb-6">
                <Award size={28} className="text-accent" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Publications & Research</h3>
              <ul className="list-disc list-inside space-y-2 text-gray-700">
                <li>Author of 15+ research papers in national and international journals</li>
                <li>Co-author of a chapter in "Advances in Laparoscopic Surgery"</li>
                <li>Regular contributor to surgical conferences</li>
                <li>Research focus on minimally invasive surgical techniques</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-12 bg-primary text-white">
        <div className="container">
          <div className="flex flex-col md:flex-row items-center justify-between gap-8">
            <div>
              <h2 className="text-2xl md:text-3xl font-bold mb-2 text-white">Ready to Schedule an Appointment?</h2>
              <p className="text-white/90">
                Contact us today to book a consultation with Dr. Mahesh Babu.
              </p>
            </div>
            <Link to="/contact" className="btn bg-white text-primary hover:bg-white/90 whitespace-nowrap flex items-center gap-2">
              Book Appointment <ArrowRight size={18} />
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default About;