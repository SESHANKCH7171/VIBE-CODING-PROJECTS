import React from 'react';
import { Link } from 'react-router-dom';
import { Calendar, User, Tag, ArrowRight, Search } from 'lucide-react';
import { blogPosts } from '../data/blogData';

const Blog = () => {
  const [searchTerm, setSearchTerm] = React.useState('');
  const [activeCategory, setActiveCategory] = React.useState('All');
  
  const categories = ['All', 'Surgery', 'Health Tips', 'Recovery', 'Patient Care'];
  
  const filteredPosts = blogPosts.filter(post => {
    const matchesSearch = post.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         post.excerpt.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = activeCategory === 'All' || post.category === activeCategory;
    
    return matchesSearch && matchesCategory;
  });

  return (
    <>
      {/* Hero Section */}
      <section className="pt-32 pb-16 md:pt-40 md:pb-20 bg-primary text-white">
        <div className="container">
          <div className="text-center max-w-3xl mx-auto">
            <h1 className="text-4xl md:text-5xl font-bold mb-6 text-white">Resources & Blog</h1>
            <p className="text-lg text-white/90">
              Explore articles, health tips, and educational resources from Dr. Mahesh Babu.
            </p>
          </div>
        </div>
      </section>

      {/* Blog Content */}
      <section className="section bg-white">
        <div className="container">
          <div className="flex flex-col lg:flex-row gap-12">
            {/* Main Content */}
            <div className="lg:w-2/3">
              {/* Search and Filters */}
              <div className="mb-12">
                <div className="relative mb-8">
                  <input
                    type="text"
                    placeholder="Search articles..."
                    className="w-full py-3 pl-12 pr-4 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                  <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                </div>
                
                <div className="flex flex-wrap gap-2">
                  {categories.map((category) => (
                    <button
                      key={category}
                      className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                        activeCategory === category
                          ? 'bg-primary text-white'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                      onClick={() => setActiveCategory(category)}
                    >
                      {category}
                    </button>
                  ))}
                </div>
              </div>
              
              {/* Blog Posts */}
              {filteredPosts.length > 0 ? (
                <div className="space-y-10">
                  {filteredPosts.map((post) => (
                    <article key={post.id} className="card overflow-hidden group">
                      <div className="h-64 bg-gray-200 relative overflow-hidden">
                        <img 
                          src={post.image} 
                          alt={post.title} 
                          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                        />
                        <div className="absolute top-4 right-4 bg-primary text-white px-3 py-1 rounded-full text-sm font-medium">
                          {post.category}
                        </div>
                      </div>
                      <div className="p-6">
                        <div className="flex items-center gap-4 text-sm text-gray-500 mb-4">
                          <div className="flex items-center gap-1">
                            <Calendar size={16} />
                            <span>{post.date}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <User size={16} />
                            <span>{post.author}</span>
                          </div>
                        </div>
                        <h3 className="text-2xl font-bold mb-3">{post.title}</h3>
                        <p className="text-gray-700 mb-4">
                          {post.excerpt}
                        </p>
                        <Link to={`/blog/${post.id}`} className="text-primary font-medium hover:text-secondary transition-colors inline-flex items-center gap-1">
                          Read More <ArrowRight size={16} />
                        </Link>
                      </div>
                    </article>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <p className="text-xl text-gray-600">No articles found matching your search criteria.</p>
                  <button 
                    className="mt-4 text-primary font-medium hover:text-secondary transition-colors"
                    onClick={() => {
                      setSearchTerm('');
                      setActiveCategory('All');
                    }}
                  >
                    Clear filters
                  </button>
                </div>
              )}
            </div>
            
            {/* Sidebar */}
            <div className="lg:w-1/3">
              {/* Categories */}
              <div className="card p-6 mb-8">
                <h3 className="text-xl font-bold mb-4">Categories</h3>
                <ul className="space-y-2">
                  {categories.filter(cat => cat !== 'All').map((category) => (
                    <li key={category}>
                      <button 
                        className="flex items-center justify-between w-full py-2 text-left hover:text-primary transition-colors"
                        onClick={() => setActiveCategory(category)}
                      >
                        <span>{category}</span>
                        <span className="bg-gray-100 px-2 py-1 rounded-full text-xs text-gray-700">
                          {blogPosts.filter(post => post.category === category).length}
                        </span>
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
              
              {/* Recent Posts */}
              <div className="card p-6 mb-8">
                <h3 className="text-xl font-bold mb-4">Recent Posts</h3>
                <ul className="space-y-4">
                  {blogPosts.slice(0, 3).map((post) => (
                    <li key={post.id} className="flex gap-3">
                      <div className="w-20 h-20 flex-shrink-0 bg-gray-200 rounded overflow-hidden">
                        <img 
                          src={post.image} 
                          alt={post.title} 
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div>
                        <h4 className="font-medium mb-1 line-clamp-2 hover:text-primary transition-colors">
                          <Link to={`/blog/${post.id}`}>{post.title}</Link>
                        </h4>
                        <div className="text-sm text-gray-500 flex items-center gap-1">
                          <Calendar size={14} />
                          <span>{post.date}</span>
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
              
              {/* Tags */}
              <div className="card p-6">
                <h3 className="text-xl font-bold mb-4">Popular Tags</h3>
                <div className="flex flex-wrap gap-2">
                  {['Surgery', 'Health Tips', 'Laparoscopy', 'Recovery', 'Wellness', 'Patient Care', 'Medical', 'General Surgery'].map((tag) => (
                    <div key={tag} className="bg-gray-100 px-3 py-1 rounded-full text-sm text-gray-700 hover:bg-primary hover:text-white transition-colors cursor-pointer flex items-center gap-1">
                      <Tag size={14} />
                      <span>{tag}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-16 bg-gray-50">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-4">Subscribe to Our Newsletter</h2>
            <p className="text-gray-600 mb-8">
              Stay updated with the latest health tips, surgical advancements, and clinic news.
            </p>
            <form className="flex flex-col sm:flex-row gap-4 max-w-xl mx-auto">
              <input 
                type="email" 
                placeholder="Your email address" 
                className="flex-grow px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                required
              />
              <button 
                type="submit" 
                className="btn btn-primary whitespace-nowrap"
              >
                Subscribe
              </button>
            </form>
            <p className="text-sm text-gray-500 mt-4">
              We respect your privacy. Unsubscribe at any time.
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default Blog;