import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Scissors, 
  Activity, 
  Heart, 
  Stethoscope, 
  Zap, 
  ArrowRight,
  CheckCircle
} from 'lucide-react';

const Services = () => {
  return (
    <>
      {/* Hero Section */}
      <section className="pt-32 pb-16 md:pt-40 md:pb-20 bg-primary text-white">
        <div className="container">
          <div className="text-center max-w-3xl mx-auto">
            <h1 className="text-4xl md:text-5xl font-bold mb-6 text-white">Our Surgical Services</h1>
            <p className="text-lg text-white/90">
              Dr. Mahesh Babu offers a comprehensive range of general surgical procedures 
              with a focus on minimally invasive techniques for optimal outcomes.
            </p>
          </div>
        </div>
      </section>

      {/* Services Overview */}
      <section className="section bg-white">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Service 1 */}
            <div className="card overflow-hidden group">
              <div className="h-48 bg-gray-200 relative overflow-hidden">
                <img 
                  src="https://images.pexels.com/photos/3376790/pexels-photo-3376790.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                  alt="General Surgery" 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute top-4 left-4 w-12 h-12 bg-white rounded-full flex items-center justify-center">
                  <Scissors className="text-primary" size={24} />
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-3">General Surgery Procedures</h3>
                <p className="text-gray-600 mb-4">
                  Comprehensive surgical solutions for a wide range of conditions affecting the abdomen, 
                  digestive tract, and other organ systems.
                </p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="text-primary" size={16} />
                    <span className="text-gray-700">Hernia repair</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="text-primary" size={16} />
                    <span className="text-gray-700">Gallbladder removal</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="text-primary" size={16} />
                    <span className="text-gray-700">Appendectomy</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="text-primary" size={16} />
                    <span className="text-gray-700">Colon surgery</span>
                  </li>
                </ul>
                <Link to="/contact" className="text-primary font-medium hover:text-secondary transition-colors inline-flex items-center gap-1">
                  Schedule Consultation <ArrowRight size={16} />
                </Link>
              </div>
            </div>

            {/* Service 2 */}
            <div className="card overflow-hidden group">
              <div className="h-48 bg-gray-200 relative overflow-hidden">
                <img 
                  src="https://images.pexels.com/photos/6129507/pexels-photo-6129507.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                  alt="Minimally Invasive Surgery" 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute top-4 left-4 w-12 h-12 bg-white rounded-full flex items-center justify-center">
                  <Activity className="text-secondary" size={24} />
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-3">Minimally Invasive Surgery</h3>
                <p className="text-gray-600 mb-4">
                  Advanced laparoscopic and endoscopic techniques that minimize recovery time, 
                  reduce scarring, and improve overall surgical outcomes.
                </p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="text-secondary" size={16} />
                    <span className="text-gray-700">Laparoscopic hernia repair</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="text-secondary" size={16} />
                    <span className="text-gray-700">Laparoscopic cholecystectomy</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="text-secondary" size={16} />
                    <span className="text-gray-700">Endoscopic procedures</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="text-secondary" size={16} />
                    <span className="text-gray-700">Minimally invasive colon surgery</span>
                  </li>
                </ul>
                <Link to="/contact" className="text-secondary font-medium hover:text-primary transition-colors inline-flex items-center gap-1">
                  Schedule Consultation <ArrowRight size={16} />
                </Link>
              </div>
            </div>

            {/* Service 3 */}
            <div className="card overflow-hidden group">
              <div className="h-48 bg-gray-200 relative overflow-hidden">
                <img 
                  src="https://images.pexels.com/photos/6753203/pexels-photo-6753203.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                  alt="Emergency Surgical Care" 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute top-4 left-4 w-12 h-12 bg-white rounded-full flex items-center justify-center">
                  <Zap className="text-accent" size={24} />
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-3">Emergency Surgical Care</h3>
                <p className="text-gray-600 mb-4">
                  Prompt and effective surgical intervention for acute conditions 
                  requiring immediate medical attention.
                </p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="text-accent" size={16} />
                    <span className="text-gray-700">Acute appendicitis</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="text-accent" size={16} />
                    <span className="text-gray-700">Intestinal obstruction</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="text-accent" size={16} />
                    <span className="text-gray-700">Perforated ulcers</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="text-accent" size={16} />
                    <span className="text-gray-700">Trauma surgery</span>
                  </li>
                </ul>
                <Link to="/contact" className="text-accent font-medium hover:text-primary transition-colors inline-flex items-center gap-1">
                  Learn More <ArrowRight size={16} />
                </Link>
              </div>
            </div>

            {/* Service 4 */}
            <div className="card overflow-hidden group">
              <div className="h-48 bg-gray-200 relative overflow-hidden">
                <img 
                  src="https://images.pexels.com/photos/7579831/pexels-photo-7579831.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                  alt="Pre and Post-operative Care" 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute top-4 left-4 w-12 h-12 bg-white rounded-full flex items-center justify-center">
                  <Heart className="text-primary" size={24} />
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-3">Pre & Post-operative Care</h3>
                <p className="text-gray-600 mb-4">
                  Comprehensive care before and after surgery to ensure the best possible 
                  outcomes and smooth recovery.
                </p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="text-primary" size={16} />
                    <span className="text-gray-700">Pre-surgical assessments</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="text-primary" size={16} />
                    <span className="text-gray-700">Customized recovery plans</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="text-primary" size={16} />
                    <span className="text-gray-700">Post-operative check-ups</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="text-primary" size={16} />
                    <span className="text-gray-700">Long-term surgical care</span>
                  </li>
                </ul>
                <Link to="/contact" className="text-primary font-medium hover:text-secondary transition-colors inline-flex items-center gap-1">
                  Schedule Consultation <ArrowRight size={16} />
                </Link>
              </div>
            </div>

            {/* Service 5 */}
            <div className="card overflow-hidden group">
              <div className="h-48 bg-gray-200 relative overflow-hidden">
                <img 
                  src="https://images.pexels.com/photos/7089401/pexels-photo-7089401.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                  alt="Surgical Consultations" 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute top-4 left-4 w-12 h-12 bg-white rounded-full flex items-center justify-center">
                  <Stethoscope className="text-secondary" size={24} />
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-3">Surgical Consultations</h3>
                <p className="text-gray-600 mb-4">
                  Expert evaluation and second opinions for patients considering surgical 
                  options or requiring specialized surgical care.
                </p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="text-secondary" size={16} />
                    <span className="text-gray-700">Comprehensive evaluations</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="text-secondary" size={16} />
                    <span className="text-gray-700">Treatment planning</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="text-secondary" size={16} />
                    <span className="text-gray-700">Second opinions</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="text-secondary" size={16} />
                    <span className="text-gray-700">Risk assessment</span>
                  </li>
                </ul>
                <Link to="/contact" className="text-secondary font-medium hover:text-primary transition-colors inline-flex items-center gap-1">
                  Book Consultation <ArrowRight size={16} />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Approach Section */}
      <section className="section bg-gray-50">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Our Surgical Approach</h2>
              <p className="mb-4 text-gray-700">
                Dr. Mahesh Babu's approach to surgical care is centered on personalization, 
                precision, and patient safety. He combines years of experience with the latest 
                techniques to deliver optimal outcomes.
              </p>
              <div className="space-y-4 mb-6">
                <div className="flex gap-3">
                  <CheckCircle className="text-primary flex-shrink-0 mt-1" size={20} />
                  <div>
                    <h3 className="font-semibold text-lg mb-1">Personalized Care</h3>
                    <p className="text-gray-600">
                      Every treatment plan is tailored to the individual patient's needs, 
                      considering their medical history, condition, and personal preferences.
                    </p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <CheckCircle className="text-primary flex-shrink-0 mt-1" size={20} />
                  <div>
                    <h3 className="font-semibold text-lg mb-1">Minimally Invasive Focus</h3>
                    <p className="text-gray-600">
                      Whenever possible, Dr. Babu utilizes minimally invasive techniques to 
                      reduce recovery time, minimize scarring, and improve patient comfort.
                    </p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <CheckCircle className="text-primary flex-shrink-0 mt-1" size={20} />
                  <div>
                    <h3 className="font-semibold text-lg mb-1">Comprehensive Care</h3>
                    <p className="text-gray-600">
                      Dr. Babu and his team provide complete care from initial consultation 
                      through post-operative recovery to ensure the best possible outcome.
                    </p>
                  </div>
                </div>
              </div>
              <Link to="/contact" className="btn btn-primary inline-flex items-center gap-2">
                Schedule a Consultation <ArrowRight size={18} />
              </Link>
            </div>
            <div className="relative">
              <div className="rounded-lg overflow-hidden shadow-xl">
                <img 
                  src="https://images.pexels.com/photos/4021775/pexels-photo-4021775.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                  alt="Surgical Approach" 
                  className="w-full h-auto"
                />
              </div>
              <div className="absolute -bottom-6 -left-6 w-32 h-32 bg-primary rounded-lg shadow-lg flex items-center justify-center p-4">
                <div className="text-center text-white">
                  <p className="text-xl font-bold">20+</p>
                  <p className="text-sm">Years Experience</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="section bg-white">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Frequently Asked Questions</h2>
            <p className="max-w-3xl mx-auto text-gray-600">
              Find answers to common questions about surgical procedures and care.
            </p>
          </div>

          <div className="max-w-3xl mx-auto">
            <div className="space-y-6">
              <div className="card p-6">
                <h3 className="text-xl font-semibold mb-2">What should I expect during the initial consultation?</h3>
                <p className="text-gray-700">
                  During your first visit, Dr. Babu will review your medical history, discuss your symptoms, 
                  perform a physical examination, and explain potential treatment options. This is also an 
                  opportunity to ask questions and address any concerns you may have.
                </p>
              </div>

              <div className="card p-6">
                <h3 className="text-xl font-semibold mb-2">How do I prepare for surgery?</h3>
                <p className="text-gray-700">
                  Dr. Babu will provide detailed pre-operative instructions specific to your procedure. 
                  Generally, this includes fasting guidelines, medication adjustments, and any necessary 
                  pre-surgical testing. Following these instructions carefully is essential for a 
                  successful procedure.
                </p>
              </div>

              <div className="card p-6">
                <h3 className="text-xl font-semibold mb-2">What is the recovery time for laparoscopic surgery?</h3>
                <p className="text-gray-700">
                  Recovery time varies depending on the specific procedure and individual factors. 
                  Most patients can return to light activities within 1-2 weeks after laparoscopic 
                  surgery, with full recovery typically taking 2-4 weeks. Dr. Babu will provide a 
                  personalized recovery timeline during your consultation.
                </p>
              </div>

              <div className="card p-6">
                <h3 className="text-xl font-semibold mb-2">Are minimally invasive procedures suitable for everyone?</h3>
                <p className="text-gray-700">
                  While minimally invasive techniques offer many benefits, they aren't appropriate for 
                  every situation. Factors such as the nature and extent of the condition, previous surgeries, 
                  and overall health determine the most suitable approach. Dr. Babu will recommend the best 
                  option based on your specific circumstances.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-12 bg-primary text-white">
        <div className="container">
          <div className="flex flex-col md:flex-row items-center justify-between gap-8">
            <div>
              <h2 className="text-2xl md:text-3xl font-bold mb-2 text-white">Need Surgical Consultation?</h2>
              <p className="text-white/90">
                Contact us today to schedule an appointment with Dr. Mahesh Babu.
              </p>
            </div>
            <Link to="/contact" className="btn bg-white text-primary hover:bg-white/90 whitespace-nowrap flex items-center gap-2">
              Book Appointment <ArrowRight size={18} />
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;