import React from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle, Calendar, ArrowRight, Quote } from 'lucide-react';
import AppointmentForm from '../components/AppointmentForm';
import TestimonialCarousel from '../components/TestimonialCarousel';

const Home = () => {
  return (
    <>
      {/* Hero Section */}
      <section className="pt-32 pb-16 md:pt-40 md:pb-24 bg-gradient-to-br from-primary via-primary to-secondary text-white">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1">
              <h1 className="text-4xl md:text-5xl font-bold mb-6 text-white leading-tight">
                Expert General Surgeon in Hyderabad with 20+ Years of Trusted Care
              </h1>
              <p className="text-lg mb-8 text-white/90">
                Dr. Mahesh Babu provides specialized surgical care with a focus on patient comfort, 
                safety, and successful outcomes. Book your consultation today.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link to="/contact" className="btn bg-accent text-primary hover:bg-accent/90">
                  Book Your Consultation
                </Link>
                <Link to="/services" className="btn bg-white/10 text-white hover:bg-white/20 backdrop-blur-sm">
                  Explore Services
                </Link>
              </div>
            </div>
            <div className="order-1 lg:order-2 flex justify-center">
              <div className="w-full max-w-md aspect-[3/4] bg-white/10 backdrop-blur-sm rounded-lg overflow-hidden shadow-xl">
                <img 
                  src="https://images.pexels.com/photos/5327585/pexels-photo-5327585.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                  alt="Dr. Mahesh Babu" 
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Section */}
      <section className="section bg-white">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Choose Dr. Mahesh Babu</h2>
            <p className="max-w-3xl mx-auto text-gray-600">
              With over two decades of surgical excellence, Dr. Mahesh Babu combines expert skills with 
              compassionate care to deliver the best outcomes for his patients.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Card 1 */}
            <div className="card p-8 border-t-4 border-primary hover:translate-y-[-5px]">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-6">
                <CheckCircle size={28} className="text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-3">20+ Years Experience</h3>
              <p className="text-gray-600">
                With over two decades of surgical practice, Dr. Mahesh brings unparalleled expertise to every procedure.
              </p>
            </div>

            {/* Card 2 */}
            <div className="card p-8 border-t-4 border-secondary hover:translate-y-[-5px]">
              <div className="w-16 h-16 bg-secondary/10 rounded-full flex items-center justify-center mb-6">
                <CheckCircle size={28} className="text-secondary" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Advanced Techniques</h3>
              <p className="text-gray-600">
                Utilizes the latest minimally invasive surgical techniques for faster recovery and reduced discomfort.
              </p>
            </div>

            {/* Card 3 */}
            <div className="card p-8 border-t-4 border-accent hover:translate-y-[-5px]">
              <div className="w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center mb-6">
                <CheckCircle size={28} className="text-accent" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Patient-Centered Care</h3>
              <p className="text-gray-600">
                Focused on providing individualized care with clear communication throughout your treatment journey.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="section bg-gray-50">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">What Our Patients Say</h2>
            <p className="max-w-3xl mx-auto text-gray-600">
              Hear from patients who have experienced Dr. Mahesh's exceptional surgical care.
            </p>
          </div>
          
          <TestimonialCarousel />
        </div>
      </section>

      {/* Appointment Form */}
      <section className="section bg-white">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Schedule Your Appointment</h2>
              <p className="text-gray-600 mb-8">
                Take the first step towards better health. Fill out the form to request an appointment, 
                and our team will contact you shortly to confirm your visit.
              </p>
              
              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                    <Calendar size={20} className="text-primary" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold mb-1">Flexible Scheduling</h3>
                    <p className="text-gray-600">
                      We offer convenient appointment times to fit your busy schedule.
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-secondary/10 rounded-full flex items-center justify-center flex-shrink-0">
                    <Calendar size={20} className="text-secondary" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold mb-1">Same-Week Consultations</h3>
                    <p className="text-gray-600">
                      Most new patients can be seen within the same week of their request.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="card p-8">
              <AppointmentForm />
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-12 bg-primary text-white">
        <div className="container">
          <div className="flex flex-col md:flex-row items-center justify-between gap-8">
            <div>
              <h2 className="text-2xl md:text-3xl font-bold mb-2 text-white">Have Questions?</h2>
              <p className="text-white/90">
                Contact us today for any inquiries about our surgical services.
              </p>
            </div>
            <Link to="/contact" className="btn bg-white text-primary hover:bg-white/90 whitespace-nowrap flex items-center gap-2">
              Contact Us <ArrowRight size={18} />
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;