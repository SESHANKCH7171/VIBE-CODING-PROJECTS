import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin, Clock, Facebook, Twitter, Instagram, Linkedin } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-primary text-white">
      <div className="container py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* About */}
          <div>
            <h3 className="text-xl font-semibold mb-4 text-white">Dr. Mahesh Babu</h3>
            <p className="mb-4">
              Providing trusted surgical care to patients in Hyderabad for over 20 years with compassion and expertise.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-white hover:text-accent transition-colors" aria-label="Facebook">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-white hover:text-accent transition-colors" aria-label="Twitter">
                <Twitter size={20} />
              </a>
              <a href="#" className="text-white hover:text-accent transition-colors" aria-label="Instagram">
                <Instagram size={20} />
              </a>
              <a href="#" className="text-white hover:text-accent transition-colors" aria-label="LinkedIn">
                <Linkedin size={20} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-xl font-semibold mb-4 text-white">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="hover:text-accent transition-colors">Home</Link>
              </li>
              <li>
                <Link to="/about" className="hover:text-accent transition-colors">About</Link>
              </li>
              <li>
                <Link to="/services" className="hover:text-accent transition-colors">Services</Link>
              </li>
              <li>
                <Link to="/blog" className="hover:text-accent transition-colors">Resources</Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-accent transition-colors">Contact</Link>
              </li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-xl font-semibold mb-4 text-white">Services</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/services" className="hover:text-accent transition-colors">General Surgery</Link>
              </li>
              <li>
                <Link to="/services" className="hover:text-accent transition-colors">Minimally Invasive Surgery</Link>
              </li>
              <li>
                <Link to="/services" className="hover:text-accent transition-colors">Emergency Surgical Care</Link>
              </li>
              <li>
                <Link to="/services" className="hover:text-accent transition-colors">Pre & Post-operative Care</Link>
              </li>
              <li>
                <Link to="/services" className="hover:text-accent transition-colors">Surgical Consultations</Link>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-xl font-semibold mb-4 text-white">Contact Info</h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-3">
                <MapPin className="mt-1 flex-shrink-0 text-accent" size={18} />
                <span>123 Medical Center, Banjara Hills, Hyderabad, 500034</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="flex-shrink-0 text-accent" size={18} />
                <a href="tel:+919876543210" className="hover:text-accent transition-colors">+91 98765 43210</a>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="flex-shrink-0 text-accent" size={18} />
                <a href="mailto:dr.mahesh@example.com" className="hover:text-accent transition-colors">dr.mahesh@example.com</a>
              </li>
              <li className="flex items-start gap-3">
                <Clock className="mt-1 flex-shrink-0 text-accent" size={18} />
                <div>
                  <p>Mon-Fri: 9:00 AM - 6:00 PM</p>
                  <p>Sat: 9:00 AM - 1:00 PM</p>
                  <p>Sun: Closed</p>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Copyright */}
      <div className="py-4 border-t border-primary-700 bg-primary-900">
        <div className="container text-center text-sm">
          <p>© {currentYear} Dr. Mahesh Babu. All Rights Reserved.</p>
          <p className="mt-1">
            <Link to="/privacy-policy" className="hover:text-accent transition-colors">Privacy Policy</Link> | 
            <Link to="/terms" className="hover:text-accent transition-colors ml-2">Terms of Service</Link>
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;