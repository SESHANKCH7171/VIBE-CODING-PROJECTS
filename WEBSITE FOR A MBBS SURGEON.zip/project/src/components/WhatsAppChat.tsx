import { useState } from 'react';
import { MessageCircle, X } from 'lucide-react';
import { format } from 'date-fns';

interface Service {
  id: string;
  name: string;
}

const services: Service[] = [
  { id: 'general', name: 'General Surgery' },
  { id: 'laparoscopic', name: 'Laparoscopic Surgery' },
  { id: 'consultation', name: 'Consultation' },
  { id: 'followup', name: 'Follow-up Visit' }
];

const timeSlots = [
  '09:00 AM - 11:00 AM',
  '11:00 AM - 01:00 PM',
  '02:00 PM - 04:00 PM',
  '04:00 PM - 06:00 PM'
];

const WhatsAppChat = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    service: '',
    date: '',
    timeSlot: ''
  });

  const handleSubmit = () => {
    const message = `Hello Dr. Mahesh Babu,\n\nI would like to schedule an appointment:\n\nName: ${formData.name}\nPhone: ${formData.phone}\nService: ${formData.service}\nDate: ${formData.date}\nTime: ${formData.timeSlot}`;
    
    const encodedMessage = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/919381232021?text=${encodedMessage}`;
    
    window.open(whatsappUrl, '_blank');
    setIsOpen(false);
    setStep(1);
    setFormData({
      name: '',
      phone: '',
      service: '',
      date: '',
      timeSlot: ''
    });
  };

  const handleDateSelect = (date: string) => {
    setFormData(prev => ({ ...prev, date }));
    setStep(4);
  };

  const getAvailableDates = () => {
    const dates = [];
    const today = new Date();
    
    for (let i = 1; i <= 7; i++) {
      const date = new Date(today);
      date.setDate(today.getDate() + i);
      if (date.getDay() !== 0) { // Exclude Sundays
        dates.push(date);
      }
    }
    
    return dates;
  };

  return (
    <>
      {/* Floating Button */}
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 bg-green-500 text-white p-4 rounded-full shadow-lg hover:bg-green-600 transition-colors z-50"
        aria-label="Open WhatsApp Chat"
      >
        <MessageCircle size={24} />
      </button>

      {/* Chat Modal */}
      {isOpen && (
        <div className="fixed bottom-24 right-6 w-96 bg-white rounded-lg shadow-xl z-50">
          {/* Header */}
          <div className="bg-green-500 text-white p-4 rounded-t-lg flex justify-between items-center">
            <h3 className="font-semibold">Schedule Appointment</h3>
            <button
              onClick={() => setIsOpen(false)}
              className="text-white hover:text-green-100"
              aria-label="Close chat"
            >
              <X size={20} />
            </button>
          </div>

          {/* Chat Content */}
          <div className="p-4 max-h-[500px] overflow-y-auto">
            {step === 1 && (
              <div className="space-y-4">
                <p className="text-gray-700">Hello! Please enter your details to schedule an appointment with Dr. Mahesh Babu.</p>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Your name"
                  className="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-green-500"
                />
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                  placeholder="Your phone number"
                  className="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-green-500"
                />
                <button
                  onClick={() => formData.name && formData.phone && setStep(2)}
                  className="w-full bg-green-500 text-white py-2 rounded hover:bg-green-600 transition-colors"
                  disabled={!formData.name || !formData.phone}
                >
                  Continue
                </button>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-4">
                <p className="text-gray-700">Hi {formData.name}! Please select the service you're interested in:</p>
                <div className="grid gap-2">
                  {services.map(service => (
                    <button
                      key={service.id}
                      onClick={() => {
                        setFormData(prev => ({ ...prev, service: service.name }));
                        setStep(3);
                      }}
                      className="text-left p-3 border rounded hover:bg-green-50 transition-colors"
                    >
                      {service.name}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-4">
                <p className="text-gray-700">Please select your preferred date:</p>
                <div className="grid gap-2">
                  {getAvailableDates().map((date, index) => (
                    <button
                      key={index}
                      onClick={() => handleDateSelect(format(date, 'MMMM d, yyyy'))}
                      className="text-left p-3 border rounded hover:bg-green-50 transition-colors"
                    >
                      {format(date, 'EEEE, MMMM d, yyyy')}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {step === 4 && (
              <div className="space-y-4">
                <p className="text-gray-700">Please select your preferred time slot:</p>
                <div className="grid gap-2">
                  {timeSlots.map((slot, index) => (
                    <button
                      key={index}
                      onClick={() => {
                        setFormData(prev => ({ ...prev, timeSlot: slot }));
                        handleSubmit();
                      }}
                      className="text-left p-3 border rounded hover:bg-green-50 transition-colors"
                    >
                      {slot}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Quick Access Menu */}
            <div className="mt-6 pt-4 border-t">
              <p className="font-medium mb-2">Quick Links:</p>
              <div className="grid grid-cols-2 gap-2">
                <a
                  href="/contact"
                  className="text-sm text-green-600 hover:text-green-700 p-2 bg-green-50 rounded text-center"
                >
                  Clinic Location
                </a>
                <a
                  href="/services"
                  className="text-sm text-green-600 hover:text-green-700 p-2 bg-green-50 rounded text-center"
                >
                  Our Services
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default WhatsAppChat;