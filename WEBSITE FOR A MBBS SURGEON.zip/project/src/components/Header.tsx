import { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import { Stethoscope, Menu, X } from 'lucide-react';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <header
      className={`fixed w-full z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'
      }`}
    >
      <div className="container flex justify-between items-center">
        <NavLink to="/" className="flex items-center gap-2">
          <Stethoscope className="h-8 w-8 text-primary" />
          <span className="text-xl font-bold text-primary">Dr. Mahesh Babu</span>
        </NavLink>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-8">
          <NavLink
            to="/"
            className={({ isActive }) =>
              `font-medium transition-colors ${
                isActive ? 'text-secondary' : 'text-primary hover:text-secondary'
              }`
            }
          >
            Home
          </NavLink>
          <NavLink
            to="/about"
            className={({ isActive }) =>
              `font-medium transition-colors ${
                isActive ? 'text-secondary' : 'text-primary hover:text-secondary'
              }`
            }
          >
            About
          </NavLink>
          <NavLink
            to="/services"
            className={({ isActive }) =>
              `font-medium transition-colors ${
                isActive ? 'text-secondary' : 'text-primary hover:text-secondary'
              }`
            }
          >
            Services
          </NavLink>
          <NavLink
            to="/blog"
            className={({ isActive }) =>
              `font-medium transition-colors ${
                isActive ? 'text-secondary' : 'text-primary hover:text-secondary'
              }`
            }
          >
            Resources
          </NavLink>
          <NavLink
            to="/contact"
            className={({ isActive }) =>
              `font-medium transition-colors ${
                isActive ? 'text-secondary' : 'text-primary hover:text-secondary'
              }`
            }
          >
            Contact
          </NavLink>
          <NavLink to="/contact" className="btn btn-primary">
            Book Appointment
          </NavLink>
        </nav>

        {/* Mobile Menu Button */}
        <button
          className="md:hidden text-primary focus:outline-none"
          onClick={toggleMenu}
          aria-label="Toggle menu"
        >
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <nav className="md:hidden bg-white shadow-lg py-4 absolute top-full left-0 right-0 border-t border-gray-200">
          <div className="container flex flex-col gap-4">
            <NavLink
              to="/"
              className={({ isActive }) =>
                `font-medium py-2 ${isActive ? 'text-secondary' : 'text-primary'}`
              }
              onClick={() => setIsMenuOpen(false)}
            >
              Home
            </NavLink>
            <NavLink
              to="/about"
              className={({ isActive }) =>
                `font-medium py-2 ${isActive ? 'text-secondary' : 'text-primary'}`
              }
              onClick={() => setIsMenuOpen(false)}
            >
              About
            </NavLink>
            <NavLink
              to="/services"
              className={({ isActive }) =>
                `font-medium py-2 ${isActive ? 'text-secondary' : 'text-primary'}`
              }
              onClick={() => setIsMenuOpen(false)}
            >
              Services
            </NavLink>
            <NavLink
              to="/blog"
              className={({ isActive }) =>
                `font-medium py-2 ${isActive ? 'text-secondary' : 'text-primary'}`
              }
              onClick={() => setIsMenuOpen(false)}
            >
              Resources
            </NavLink>
            <NavLink
              to="/contact"
              className={({ isActive }) =>
                `font-medium py-2 ${isActive ? 'text-secondary' : 'text-primary'}`
              }
              onClick={() => setIsMenuOpen(false)}
            >
              Contact
            </NavLink>
            <NavLink
              to="/contact"
              className="btn btn-primary w-full text-center"
              onClick={() => setIsMenuOpen(false)}
            >
              Book Appointment
            </NavLink>
          </div>
        </nav>
      )}
    </header>
  );
};

export default Header;