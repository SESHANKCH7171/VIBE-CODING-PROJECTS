import React, { useState } from 'react';
import { Calendar, Clock } from 'lucide-react';

const AppointmentForm = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    service: '',
    date: '',
    time: '',
    message: '',
  });

  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real application, you would send this data to your backend
    console.log('Form submitted:', formData);
    setSubmitted(true);
    
    // Reset form after submission (in a real app, you might do this after successful API response)
    setTimeout(() => {
      setFormData({
        name: '',
        email: '',
        phone: '',
        service: '',
        date: '',
        time: '',
        message: '',
      });
      setSubmitted(false);
    }, 5000);
  };

  if (submitted) {
    return (
      <div className="text-center py-8">
        <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
          </svg>
        </div>
        <h3 className="text-xl font-semibold mb-2">Appointment Request Received</h3>
        <p className="text-gray-600 mb-4">
          Thank you for requesting an appointment. Our team will contact you shortly to confirm your appointment.
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit}>
      <div className="form-control">
        <label htmlFor="name" className="form-label">Full Name*</label>
        <input
          type="text"
          id="name"
          name="name"
          value={formData.name}
          onChange={handleChange}
          className="form-input"
          placeholder="John Doe"
          required
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="form-control">
          <label htmlFor="email" className="form-label">Email Address*</label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            className="form-input"
            placeholder="john@example.com"
            required
          />
        </div>

        <div className="form-control">
          <label htmlFor="phone" className="form-label">Phone Number*</label>
          <input
            type="tel"
            id="phone"
            name="phone"
            value={formData.phone}
            onChange={handleChange}
            className="form-input"
            placeholder="+91 98765 43210"
            required
          />
        </div>
      </div>

      <div className="form-control">
        <label htmlFor="service" className="form-label">Service Required*</label>
        <select
          id="service"
          name="service"
          value={formData.service}
          onChange={handleChange}
          className="form-input"
          required
        >
          <option value="">Select a service</option>
          <option value="General Surgery">General Surgery</option>
          <option value="Minimally Invasive Surgery">Minimally Invasive Surgery</option>
          <option value="Surgical Consultation">Surgical Consultation</option>
          <option value="Second Opinion">Second Opinion</option>
          <option value="Follow-up Visit">Follow-up Visit</option>
        </select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="form-control">
          <label htmlFor="date" className="form-label">Preferred Date*</label>
          <div className="relative">
            <input
              type="date"
              id="date"
              name="date"
              value={formData.date}
              onChange={handleChange}
              className="form-input pl-10"
              min={new Date().toISOString().split('T')[0]}
              required
            />
            <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
          </div>
        </div>

        <div className="form-control">
          <label htmlFor="time" className="form-label">Preferred Time*</label>
          <div className="relative">
            <select
              id="time"
              name="time"
              value={formData.time}
              onChange={handleChange}
              className="form-input pl-10"
              required
            >
              <option value="">Select time</option>
              <option value="Morning (9AM-12PM)">Morning (9AM-12PM)</option>
              <option value="Afternoon (12PM-3PM)">Afternoon (12PM-3PM)</option>
              <option value="Evening (3PM-6PM)">Evening (3PM-6PM)</option>
            </select>
            <Clock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
          </div>
        </div>
      </div>

      <div className="form-control">
        <label htmlFor="message" className="form-label">Message (Optional)</label>
        <textarea
          id="message"
          name="message"
          value={formData.message}
          onChange={handleChange}
          className="form-input min-h-[100px]"
          placeholder="Please provide any additional information about your condition or requirements."
        ></textarea>
      </div>

      <button type="submit" className="btn btn-primary w-full mt-4">
        Request Appointment
      </button>
      
      <p className="text-xs text-gray-500 mt-4">
        * Required fields. By submitting this form, you agree to our privacy policy and consent to be contacted regarding your appointment request.
      </p>
    </form>
  );
};

export default AppointmentForm;