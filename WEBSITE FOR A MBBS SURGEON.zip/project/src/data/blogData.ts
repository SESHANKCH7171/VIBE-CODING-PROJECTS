export interface BlogPost {
  id: number;
  title: string;
  excerpt: string;
  date: string;
  author: string;
  category: string;
  image: string;
}

export const blogPosts: BlogPost[] = [
  {
    id: 1,
    title: "Understanding Laparoscopic Surgery: Benefits and Recovery",
    excerpt: "Laparoscopic surgery has revolutionized surgical procedures. Learn about its benefits, including smaller incisions, reduced pain, and faster recovery times.",
    date: "April 15, 2025",
    author: "Dr. Mahesh Babu",
    category: "Surgery",
    image: "https://images.pexels.com/photos/3376788/pexels-photo-3376788.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
  },
  {
    id: 2,
    title: "Preparing for Your Surgery: A Comprehensive Guide",
    excerpt: "Proper preparation can significantly impact your surgical outcome. This guide provides step-by-step instructions on what to do before your procedure.",
    date: "April 2, 2025",
    author: "Dr. Mahesh Babu",
    category: "Patient Care",
    image: "https://images.pexels.com/photos/3845810/pexels-photo-3845810.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
  },
  {
    id: 3,
    title: "Common Symptoms of Gallbladder Issues You Shouldn't Ignore",
    excerpt: "Gallbladder problems can manifest in various ways. Learn to recognize the warning signs that might indicate you need to consult with a surgeon.",
    date: "March 20, 2025",
    author: "Dr. Mahesh Babu",
    category: "Health Tips",
    image: "https://images.pexels.com/photos/7089401/pexels-photo-7089401.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
  },
  {
    id: 4,
    title: "Post-Surgical Recovery: Tips for a Smooth Healing Process",
    excerpt: "Recovery after surgery is a critical phase. These evidence-based tips will help you navigate your recovery period with greater comfort and confidence.",
    date: "March 10, 2025",
    author: "Dr. Mahesh Babu",
    category: "Recovery",
    image: "https://images.pexels.com/photos/7088497/pexels-photo-7088497.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
  },
  {
    id: 5,
    title: "Advances in Minimally Invasive Surgical Techniques",
    excerpt: "The field of surgery continues to evolve with new minimally invasive approaches. Explore the latest innovations that are improving patient outcomes.",
    date: "February 28, 2025",
    author: "Dr. Mahesh Babu",
    category: "Surgery",
    image: "https://images.pexels.com/photos/5327656/pexels-photo-5327656.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
  },
  {
    id: 6,
    title: "The Importance of Regular Health Screenings",
    excerpt: "Preventive healthcare can detect issues before they become serious. Learn which screenings are recommended based on age, gender, and risk factors.",
    date: "February 15, 2025",
    author: "Dr. Mahesh Babu",
    category: "Health Tips",
    image: "https://images.pexels.com/photos/7089020/pexels-photo-7089020.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
  }
];