export interface Testimonial {
  name: string;
  title: string;
  text: string;
  avatar: string;
}

export const testimonials: Testimonial[] = [
  {
    name: "Rajesh Kumar",
    title: "Gallbladder Surgery Patient",
    text: "Dr. Mahesh Babu is an exceptional surgeon. He performed my gallbladder surgery with such precision that I had minimal pain and a quick recovery. His clear explanations before and after the procedure helped ease my anxiety.",
    avatar: "https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
  },
  {
    name: "Priya Sharma",
    title: "Hernia Repair Patient",
    text: "I was nervous about my hernia repair, but Dr. Babu's confident and compassionate approach put me at ease. He used minimally invasive techniques which resulted in less scarring and a faster return to my normal activities. I highly recommend him!",
    avatar: "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
  },
  {
    name: "Vikram Reddy",
    title: "Appendectomy Patient",
    text: "When I was rushed to the hospital with appendicitis, Dr. Mahesh Babu was called in. His quick decision-making and surgical expertise saved me from complications. The follow-up care was equally impressive. He's truly the best surgeon in Hyderabad.",
    avatar: "https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
  },
  {
    name: "Ananya Patel",
    title: "Minimally Invasive Surgery Patient",
    text: "I had been putting off my surgery due to fear, but Dr. Babu's patient explanation of the laparoscopic procedure convinced me. His skill is remarkable - I was back to work within a week! His entire team provided excellent care throughout my treatment.",
    avatar: "https://images.pexels.com/photos/733872/pexels-photo-733872.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
  }
];